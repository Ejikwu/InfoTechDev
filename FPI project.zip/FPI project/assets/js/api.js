/* ==========================================================
   api.js – THE ONLY FILE THE BACK-END DEVELOPER NEEDS TO EDIT.
   Every page calls HealthPassAPI.<method>(). Each method maps to
   one REST endpoint (documented beside it). To connect the real
   server: set CONFIG.USE_MOCK = false and CONFIG.BASE_URL.
   Expected: JSON in/out, header "Authorization: Bearer <token>".
   Offline: failed writes are queued in localStorage ("hp_queue")
   and replayed by syncQueue() when the connection returns.
   ========================================================== */
const CONFIG = { USE_MOCK: true, BASE_URL: '/api' };

/* ---- Mock data (delete once the real back end is live) ---- */
const MOCK = {
  me:{id:'HP-0234-8891',name:'Amina Yusuf',balance:12500,nextVisit:'Next visit · 24 October — Antenatal check-up at Rural PHC'},
  vaccines:[
    {name:'Tetanus · Dose 1',status:'done',info:'Rural PHC · Nurse Ngozi · 12 Sep 2026'},
    {name:'Hepatitis B · Dose 2',status:'overdue',info:'Due 10 Oct · 7 days overdue'},
    {name:'Tetanus · Dose 2',status:'due',info:'At your next antenatal visit · 24 Oct 2026'}],
  visits:[{name:'Antenatal follow-up',status:'done',info:'03 Oct · BP 112/72 · Nurse Grace Ibrahim'},
          {name:'General consultation',status:'done',info:'12 Sep · Uncomplicated malaria · CHO Funke Okafor'}],
  charge:{id:'CH-1',clinic:'Rural PHC',amount:2500,for:'Antenatal consultation'},
  queue:[{name:'Amina Yusuf',id:'HP-0234-8891',time:'09:05',service:'General consultation',status:'Ready for visit'},
         {name:'Chinedu Okeke',id:'HP-0234-9072',time:'09:12',service:'Blood pressure review',status:'In consultation'},
         {name:'Zainab Bello',id:'HP-0234-7650',time:'09:18',service:'Antenatal care',status:'Waiting'},
         {name:'Emmanuel Adeyemi',id:'HP-0234-8126',time:'09:23',service:'Child immunisation',status:'Waiting'},
         {name:'Ngozi Eze',id:'HP-0234-6823',time:'09:31',service:'Follow-up visit',status:'At triage'}],
  patients:[{name:'Amina Yusuf',id:'HP-0234-8891',age:28,sex:'Female',phone:'0803 456 7821',last:'03 Oct 2026',wallet:12500,status:'Verified'},
            {name:'Aminat Yusuf',id:'HP-0234-8912',age:28,sex:'Female',phone:'0803 456 7821',last:'16 Sep 2026',wallet:0,status:'Possible duplicate'},
            {name:'Amina Usman',id:'HP-0234-6540',age:34,sex:'Female',phone:'0805 312 0649',last:'11 Oct 2026',wallet:4200,status:'Verified'},
            {name:'Amina Abdullahi',id:'HP-0234-9013',age:22,sex:'Female',phone:'0812 087 5632',last:'08 Oct 2026',wallet:850,status:'Verified'},
            {name:'Aminatu Bello',id:'HP-0234-7238',age:41,sex:'Female',phone:'0806 781 4430',last:'28 Sep 2026',wallet:6000,status:'Verified'}],
  bill:{invoice:'INV-2026-1048',visit:'V-2026-1048',items:[
        {name:'General consultation',kind:'Service',qty:1,price:1500},
        {name:'Malaria rapid diagnostic test',kind:'Laboratory',qty:1,price:800},
        {name:'Paracetamol 500 mg',kind:'Drug',qty:10,price:20}]}
};
const wait = ms => new Promise(r => setTimeout(r, ms)); // fake network delay

/* ---- Core request helper ---- */
async function request(method, path, body){
  if (CONFIG.USE_MOCK){ await wait(200); return structuredClone(mockRoute(method, path, body)); }
  try{
    const res = await fetch(CONFIG.BASE_URL + path, {
      method, headers:{'Content-Type':'application/json','Authorization':'Bearer '+(localStorage.getItem('hp_token')||'')},
      body: body ? JSON.stringify(body) : undefined });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  }catch(err){
    if (method !== 'GET') queueWrite(method, path, body); // keep offline writes
    throw err;
  }
}
function queueWrite(method, path, body){
  const q = JSON.parse(localStorage.getItem('hp_queue')||'[]'); q.push({method,path,body});
  localStorage.setItem('hp_queue', JSON.stringify(q));
}
async function syncQueue(){ // runs when the browser comes back online
  const q = JSON.parse(localStorage.getItem('hp_queue')||'[]'); localStorage.removeItem('hp_queue');
  for (const j of q){ try{ await request(j.method, j.path, j.body); }catch(e){} }
}
function mockRoute(method, path, body){ // stand-in for the real server
  if (path==='/me') return MOCK.me;
  if (path==='/me/vaccinations') return MOCK.vaccines;
  if (path==='/me/visits') return MOCK.visits;
  if (path==='/me/pending-charge') return MOCK.charge;
  if (path.startsWith('/me/charges/')){
    if (body.decline) return {ok:true};
    if (body.pin==='1234'){ MOCK.me.balance-=MOCK.charge.amount; return {ok:true}; }
    throw new Error('Wrong PIN (demo PIN is 1234)'); }
  if (path==='/staff/dashboard') return {seen:24,registrations:6,payments:48500,lowBalance:3,queue:MOCK.queue};
  if (path.startsWith('/staff/patients?q=')){ const q=decodeURIComponent(path.split('=')[1]).toLowerCase();
    return MOCK.patients.filter(p=>(p.name+p.id+p.phone).toLowerCase().includes(q)); }
  if (path==='/staff/bill/current') return MOCK.bill;
  return {ok:true};
}

/* ---- Public API used by the pages ---- */
const HealthPassAPI = {
  /* POST /patients {name,phone,dob,gender,nin?}   -> {id}                     */ register:d=>request('POST','/patients',d),
  /* GET  /me                                      -> {id,name,balance,nextVisit} */ getMe:()=>request('GET','/me'),
  /* GET  /me/vaccinations   -> [{name,status:done|due|overdue,info}]           */ getVaccinations:()=>request('GET','/me/vaccinations'),
  /* GET  /me/visits         -> [{name,status,info}]                            */ getVisits:()=>request('GET','/me/visits'),
  /* GET  /me/pending-charge -> {id,clinic,amount,for}  (404/null if none)      */ getPendingCharge:()=>request('GET','/me/pending-charge'),
  /* POST /me/charges/:id {pin} | {decline:true}     -> {ok}                    */ answerCharge:(id,b)=>request('POST','/me/charges/'+id,b),
  /* GET  /staff/dashboard   -> {seen,registrations,payments,lowBalance,queue[]} */ getDashboard:()=>request('GET','/staff/dashboard'),
  /* GET  /staff/patients?q= -> [patient]                                       */ searchPatients:q=>request('GET','/staff/patients?q='+encodeURIComponent(q)),
  /* POST /staff/visits {patientId,complaint,diagnosis,treatment,notes,vitals}  */ saveVisit:d=>request('POST','/staff/visits',d),
  /* GET  /staff/bill/current -> bill                                           */ getBill:()=>request('GET','/staff/bill/current'),
  /* POST /staff/payment-requests {invoice,amount}: patient approves with PIN; staff NEVER see the PIN */ requestPayment:d=>request('POST','/staff/payment-requests',d)
};

/* ==========================================================
   v2 ADDITIONS – auth, profile, clinics, cross-hospital history.
   Endpoints (real server):
     POST /auth/login {id,pin} -> {token}      POST /auth/logout
     PATCH /me {photo}  (photo = small JPEG data-URL, or upload as multipart and return a URL)
     POST /me/topup {amount} -> {balance}      GET /me/history -> [history item]
     GET /clinics?q=&state= -> [clinic]        POST /clinics {name,state,lga,address,phone,services[],admin}
     GET /staff/patients/:id/history -> [history item]  (EVERY hospital's records for that HealthPass ID, nationwide)
   history item = {date,clinic,type:'Visit'|'Drug'|'Payment'|'Vaccine',title,detail,amount}  (amount negative = money spent)
   The mock below keeps users in localStorage so the demo works with no server.
   ========================================================== */
const LS = { get:(k,d)=>JSON.parse(localStorage.getItem(k)||JSON.stringify(d)), set:(k,v)=>localStorage.setItem(k,JSON.stringify(v)) };
const DEMO = {id:'HP-0234-8891',name:'Amina Yusuf',phone:'08034567821',dob:'1998-05-14',gender:'Female',nin:'',pin:'1234',photo:'',balance:12500};
const HISTORY = [
 {date:'03 Oct 2026',clinic:'Rural PHC, Gwagwalada',type:'Visit',title:'Antenatal follow-up',detail:'BP 112/72 · Nurse Grace Ibrahim',amount:0},
 {date:'03 Oct 2026',clinic:'Rural PHC, Gwagwalada',type:'Payment',title:'Antenatal consultation',detail:'Wallet payment · HP-TXN-0902',amount:-2500},
 {date:'12 Sep 2026',clinic:'Rural PHC, Gwagwalada',type:'Visit',title:'General consultation',detail:'Uncomplicated malaria · Treatment completed',amount:0},
 {date:'12 Sep 2026',clinic:'Rural PHC, Gwagwalada',type:'Drug',title:'Artemether-lumefantrine (6 tabs)',detail:'Dispensed',amount:-1800},
 {date:'20 Jun 2026',clinic:'Ilaro General Hospital, Ogun',type:'Visit',title:'Antenatal booking',detail:'Booking scan and bloods · Dr. Adebayo',amount:0},
 {date:'20 Jun 2026',clinic:'Ilaro General Hospital, Ogun',type:'Payment',title:'Booking fee',detail:'Wallet payment',amount:-5000}];
const CLINICS = [
 {id:'PHC-0142',name:'Rural PHC, Gwagwalada',state:'FCT',lga:'Gwagwalada',address:'Gwagwalada Road',phone:'0803 111 2201',services:['Antenatal','Immunisation','General']},
 {id:'OG-0007',name:'Ilaro General Hospital',state:'Ogun',lga:'Yewa South',address:'Hospital Road, Ilaro',phone:'0803 222 3302',services:['Antenatal','Laboratory','Pharmacy']},
 {id:'OG-0031',name:'Abeokuta Community Health Centre',state:'Ogun',lga:'Abeokuta South',address:'Isale Igbein',phone:'0803 333 4403',services:['Immunisation','General']},
 {id:'LA-0112',name:'Ikeja Primary Health Centre',state:'Lagos',lga:'Ikeja',address:'Obafemi Awolowo Way',phone:'0803 444 5504',services:['Antenatal','Immunisation']},
 {id:'KN-0054',name:'Nasarawa Maternal Clinic',state:'Kano',lga:'Nasarawa',address:'Zoo Road',phone:'0803 555 6605',services:['Antenatal','Pharmacy']},
 {id:'OY-0063',name:'Ibadan Wesley Health Centre',state:'Oyo',lga:'Ibadan North',address:'Oke Ado',phone:'0803 666 7706',services:['General','Laboratory']}];
const users = () => { const u = LS.get('hp_users',null) || {[DEMO.id]:DEMO}; return u; };
const sessionUser = (all=users()) => { const id = localStorage.getItem('hp_session'); const u = all[id]; if(!u) throw new Error('401'); return u; };
const digits = s => String(s).replace(/\D/g,'');
const baseRoute = mockRoute;
mockRoute = function(method, path, body){
  const all = users();
  if (path==='/patients'){ const id='HP-0234-'+Math.floor(1000+Math.random()*9000);
    all[id]={id,name:body.name,phone:digits(body.phone),dob:body.dob,gender:body.gender,nin:body.nin||'',pin:body.pin,photo:'',balance:0};
    LS.set('hp_users',all); localStorage.setItem('hp_session',id); return {id}; }
  if (path==='/auth/login'){ const u=Object.values(all).find(x=>x.id.toLowerCase()===body.id.trim().toLowerCase()||x.phone===digits(body.id));
    if(!u||u.pin!==body.pin) throw new Error('Wrong HealthPass ID/phone or PIN (demo: HP-0234-8891 / 1234)');
    localStorage.setItem('hp_session',u.id); return {token:'demo'}; }
  if (path==='/auth/logout'){ localStorage.removeItem('hp_session'); return {ok:true}; }
  if (path==='/me'){ const u=sessionUser(all);
    if(method==='PATCH'){ Object.assign(u,body); LS.set('hp_users',all); }
    return {...u, pin:undefined, balance: u.id===DEMO.id ? MOCK.me.balance : u.balance, nextVisit: u.id===DEMO.id ? MOCK.me.nextVisit : ''}; }
  if (path==='/me/topup'){ const u=sessionUser(all); u.balance+=body.amount; if(u.id===DEMO.id) MOCK.me.balance+=body.amount; LS.set('hp_users',all); return {balance:u.balance}; }
  if (path==='/me/history'){ return sessionUser(all).id===DEMO.id ? HISTORY : []; }
  if (path==='/me/visits'||path==='/me/vaccinations'){ if(sessionUser(all).id!==DEMO.id) return []; }
  if (path.startsWith('/clinics')){ const mine=LS.get('hp_clinics',[]); if(method==='POST'){ mine.push({id:'NEW-'+(mine.length+1),...body}); LS.set('hp_clinics',mine); return {ok:true}; }
    const p=new URLSearchParams(path.split('?')[1]||''), q=(p.get('q')||'').toLowerCase(), s=p.get('state')||'';
    return [...CLINICS,...mine].filter(c=>(!s||c.state===s)&&(c.name+c.lga+c.state).toLowerCase().includes(q)); }
  if (/^\/staff\/patients\/.+\/history$/.test(path)) return path.includes(DEMO.id) ? HISTORY : [];
  if (path.startsWith('/staff/patients?q=')){ const q=decodeURIComponent(path.split('=')[1]).toLowerCase(), r=baseRoute(method,path,body);
    const extra=Object.values(all).filter(u=>u.id!==DEMO.id&&(u.name+u.id+u.phone).toLowerCase().includes(q)).map(u=>({name:u.name,id:u.id,age:new Date().getFullYear()-+u.dob.slice(0,4),sex:u.gender,phone:u.phone,last:'—',wallet:u.balance,status:'Verified'}));
    return [...r,...extra]; }
  return baseRoute(method,path,body);
};
Object.assign(HealthPassAPI,{
  login:d=>request('POST','/auth/login',d), logout:()=>request('POST','/auth/logout'),
  updateMe:d=>request('PATCH','/me',d), topUp:amount=>request('POST','/me/topup',{amount}), getHistory:()=>request('GET','/me/history'),
  getClinics:(q='',state='')=>request('GET','/clinics?q='+encodeURIComponent(q)+'&state='+encodeURIComponent(state)),
  registerClinic:d=>request('POST','/clinics',d), getPatientHistory:id=>request('GET','/staff/patients/'+id+'/history')
});

/* ==========================================================
   v3 ADDITIONS – staff portal, clinic/staff registration, approvals, audit log.
   ROLES:  admin    = HealthPass main admin (approves clinics, sees everything)
           subadmin = a clinic's admin (becomes this once the main admin approves the clinic; approves their own staff)
           staff    = one person = one login. Registers under a clinic; the clinic's subadmin approves them.
   ACCOUNT STATUS: pending -> approved | rejected ;  approved <-> suspended.   CLINIC STATUS: same.
   Endpoints (real server – ENFORCE ROLE CHECKS SERVER-SIDE, the UI hiding buttons is not security):
     POST /portal/login {username,password} -> account+clinic     POST /portal/logout     GET /portal/me
     GET  /portal/clinics (public, approved only, for the staff-registration dropdown)
     POST /portal/clinic-register {clinic:{id,name,state,lga,address,phone,licence,services[]}, admin:{name,phone,username,password}}
     POST /portal/staff-register  {clinicId,name,title,phone,licence,username,password}
     POST /portal/contact {name,username,clinicId,text}
     GET  /admin/overview | /admin/clinics | /admin/accounts | /admin/patients | /admin/audit | /admin/messages
          (subadmin gets only their own clinic's data; admin gets all)
     POST /admin/clinics/:id {status}   (admin only)      POST /admin/accounts/:username {status}  (admin: anyone; subadmin: own staff)
   AUDIT: the SERVER must write an audit row for every staff action (login, search, view patient, save visit, payment request,
          approvals). The mock below does it automatically so the UI can be demoed.
   PASSWORDS: stored in plain text in this MOCK ONLY. The real server must hash them (bcrypt/argon2).
   ========================================================== */
const iso = (minsAgo=0) => new Date(Date.now()-minsAgo*60000).toISOString();
const SEED_ACC = [
 {username:'admin',password:'admin123',role:'admin',name:'HealthPass Main Admin',title:'Platform administrator',phone:'',clinicId:'',status:'approved',created:iso(99999)},
 {username:'phc0142',password:'clinic123',role:'subadmin',name:'Dr. Halima Sule',title:'Clinic administrator',phone:'0803 111 2201',clinicId:'PHC-0142',status:'approved',created:iso(80000)},
 {username:'funke',password:'staff123',role:'staff',name:'Funke Okafor',title:'Community health officer',phone:'0806 100 2000',clinicId:'PHC-0142',status:'approved',created:iso(70000)},
 {username:'grace',password:'staff123',role:'staff',name:'Grace Ibrahim',title:'Nurse',phone:'0806 300 4000',clinicId:'PHC-0142',status:'pending',created:iso(120)},
 {username:'ilarogh',password:'clinic123',role:'subadmin',name:'Dr. Tunde Adebayo',title:'Clinic administrator',phone:'0803 222 3302',clinicId:'OG-0007',status:'approved',created:iso(60000)},
 {username:'offa',password:'clinic123',role:'subadmin',name:'Mrs. Bola Ajayi',title:'Clinic administrator',phone:'0803 777 8807',clinicId:'OF-0099',status:'pending',created:iso(300)}];
const SEED_CLINICS = () => [...CLINICS.map(c=>({...c,status:'approved',licence:'LIC-'+c.id})),
 {id:'OF-0099',name:'Offa Maternal Centre',state:'Kwara',lga:'Offa',address:'Ojoku Road',phone:'0803 777 8807',licence:'KW-2231',services:['Antenatal'],status:'pending'}];
const accs = () => LS.get('hp_accounts',null) || (LS.set('hp_accounts',SEED_ACC), SEED_ACC);
const clinicsAll = () => LS.get('hp_clinics3',null) || (LS.set('hp_clinics3',SEED_CLINICS()), LS.get('hp_clinics3',[]));
const auditAll = () => LS.get('hp_audit',null) || (LS.set('hp_audit',[
 {t:iso(50),user:'funke',name:'Funke Okafor',role:'staff',clinicId:'PHC-0142',action:'Saved visit',detail:'Antenatal follow-up',patientId:'HP-0234-8891'},
 {t:iso(55),user:'funke',name:'Funke Okafor',role:'staff',clinicId:'PHC-0142',action:'Viewed patient record',detail:'',patientId:'HP-0234-8891'},
 {t:iso(90),user:'phc0142',name:'Dr. Halima Sule',role:'subadmin',clinicId:'PHC-0142',action:'Account approved',detail:'funke',patientId:''},
 {t:iso(200),user:'ilarogh',name:'Dr. Tunde Adebayo',role:'subadmin',clinicId:'OG-0007',action:'Logged in',detail:'',patientId:''}]), LS.get('hp_audit',[]));
function logAudit(u, action, detail='', patientId=''){ const a=auditAll(); a.unshift({t:iso(),user:u.username,name:u.name,role:u.role,clinicId:u.clinicId,action,detail,patientId}); LS.set('hp_audit',a.slice(0,500)); }
const stripPw = (a,C) => { const {password,...r}=a; return {...r, clinic:C.find(c=>c.id===a.clinicId)||null}; };
function portalRoute(method, path, b){
  const A=accs(), C=clinicsAll(), saveA=()=>LS.set('hp_accounts',A), saveC=()=>LS.set('hp_clinics3',C);
  const me=()=>{ const u=A.find(x=>x.username===localStorage.getItem('hp_staff')); if(!u) throw new Error('401'); return u; };
  const taken = n => A.some(x=>x.username===n);
  if(path==='/portal/login'){ const u=A.find(x=>x.username===b.username.trim().toLowerCase()&&x.password===b.password);
    if(!u) throw new Error('Wrong username or password.');
    const c=C.find(x=>x.id===u.clinicId);
    if(u.status==='pending') throw new Error('Your account is awaiting approval. Use "Contact admin" if it takes too long.');
    if(u.status==='rejected') throw new Error('Your registration was not approved. Please contact admin.');
    if(u.status==='suspended') throw new Error('Your account is suspended. Please contact admin.');
    if(u.role!=='admin' && (!c||c.status!=='approved')) throw new Error('Your clinic is not active. Please contact admin.');
    localStorage.setItem('hp_staff',u.username); logAudit(u,'Logged in'); return stripPw(u,C); }
  if(path==='/portal/logout'){ const u=A.find(x=>x.username===localStorage.getItem('hp_staff')); if(u) logAudit(u,'Logged out'); localStorage.removeItem('hp_staff'); return {ok:true}; }
  if(path==='/portal/me') return stripPw(me(),C);
  if(path==='/portal/clinics') return C.filter(c=>c.status==='approved').map(({id,name,state,lga})=>({id,name,state,lga}));
  if(path==='/portal/clinic-register'){ const c=b.clinic, a=b.admin, id=c.id.trim().toUpperCase(), un=a.username.trim().toLowerCase();
    if(C.some(x=>x.id===id)) throw new Error('This clinic number is already registered.'); if(taken(un)) throw new Error('That username is taken.');
    C.push({...c,id,status:'pending'}); A.push({username:un,password:a.password,role:'subadmin',name:a.name,title:'Clinic administrator',phone:a.phone,clinicId:id,status:'pending',created:iso()}); saveC(); saveA(); return {ok:true}; }
  if(path==='/portal/staff-register'){ const un=b.username.trim().toLowerCase(); const c=C.find(x=>x.id===b.clinicId&&x.status==='approved');
    if(!c) throw new Error('Choose an approved clinic.'); if(taken(un)) throw new Error('That username is taken.');
    A.push({username:un,password:b.password,role:'staff',name:b.name,title:b.title,phone:b.phone,licence:b.licence,clinicId:c.id,status:'pending',created:iso()}); saveA(); return {ok:true}; }
  if(path==='/portal/contact'){ const m=LS.get('hp_msgs',[]); m.unshift({t:iso(),...b}); LS.set('hp_msgs',m); return {ok:true}; }
  /* ---- admin area ---- */
  const u=me(); if(u.role==='staff') throw new Error('403'); const main=u.role==='admin';
  if(path==='/admin/overview'){ const day=auditAll().filter(x=>Date.now()-new Date(x.t)<864e5&&(main||x.clinicId===u.clinicId));
    return {role:u.role, clinics:C.filter(c=>c.status==='approved').length, pendingClinics:C.filter(c=>c.status==='pending').length,
      subadmins:A.filter(a=>a.role==='subadmin'&&a.status==='approved').length,
      staff:A.filter(a=>a.role==='staff'&&a.status==='approved'&&(main||a.clinicId===u.clinicId)).length,
      pendingStaff:A.filter(a=>a.role==='staff'&&a.status==='pending'&&(main||a.clinicId===u.clinicId)).length,
      patients:main?Object.keys(users()).length+MOCK.patients.length-1:new Set(auditAll().filter(x=>x.clinicId===u.clinicId&&x.patientId).map(x=>x.patientId)).size, actions:day.length}; }
  if(path==='/admin/clinics'){ if(!main) throw new Error('403'); return C.map(c=>({...c,admin:(A.find(a=>a.clinicId===c.id&&a.role==='subadmin')||{}).name||'—'})); }
  if(path==='/admin/accounts') return A.filter(a=>main?a.role!=='admin':(a.role==='staff'&&a.clinicId===u.clinicId)).map(a=>stripPw(a,C));
  if(path==='/admin/audit') return auditAll().filter(x=>main||x.clinicId===u.clinicId).slice(0,200).map(x=>({...x,clinic:(C.find(c=>c.id===x.clinicId)||{}).name||'HealthPass'}));
  if(path==='/admin/messages'){ if(!main) throw new Error('403'); return LS.get('hp_msgs',[]); }
  if(path==='/admin/patients'){ const reg=Object.values(users()).filter(x=>x.id!==DEMO.id).map(x=>({name:x.name,id:x.id,phone:x.phone,sex:x.gender,last:'—'}));
    const all=[...MOCK.patients.filter(p=>p.status==='Verified').map(p=>({name:p.name,id:p.id,phone:p.phone,sex:p.sex,last:p.last})),...reg];
    if(main) return all; const seen=new Set(auditAll().filter(x=>x.clinicId===u.clinicId&&x.patientId).map(x=>x.patientId)); return all.filter(p=>seen.has(p.id)); }
  let m;
  if(m=path.match(/^\/admin\/clinics\/(.+)$/)){ if(!main) throw new Error('403'); const c=C.find(x=>x.id===m[1]); c.status=b.status;
    A.filter(a=>a.clinicId===c.id&&a.role==='subadmin').forEach(a=>{ a.status = b.status==='approved' ? 'approved' : b.status==='rejected' ? 'rejected' : a.status; });
    saveC(); saveA(); logAudit(u,'Clinic '+b.status,c.name); return {ok:true}; }
  if(m=path.match(/^\/admin\/accounts\/(.+)$/)){ const a=A.find(x=>x.username===m[1]);
    if(!a||a.role==='admin'||(!main&&(a.role!=='staff'||a.clinicId!==u.clinicId))) throw new Error('403');
    a.status=b.status; saveA(); logAudit(u,'Account '+b.status,a.username+' ('+a.name+')'); return {ok:true}; }
  throw new Error('404');
}
/* Wrap the older mock: portal/admin routes, public clinic search (approved only) and automatic audit of staff actions */
const route2 = mockRoute;
mockRoute = function(method, path, body){
  if(path.startsWith('/portal/')||path.startsWith('/admin/')) return portalRoute(method,path,body);
  if(method==='GET' && path.startsWith('/clinics')){ const p=new URLSearchParams(path.split('?')[1]||''), q=(p.get('q')||'').toLowerCase(), s=p.get('state')||'';
    return clinicsAll().filter(c=>c.status==='approved'&&(!s||c.state===s)&&(c.name+c.lga+c.state).toLowerCase().includes(q)); }
  if(path.startsWith('/staff/')){ const u=accs().find(x=>x.username===localStorage.getItem('hp_staff')); if(!u) throw new Error('401');
    let h; if(method==='POST'&&path==='/staff/visits') logAudit(u,'Saved visit',body.diagnosis,body.patientId);
    else if(method==='POST'&&path==='/staff/payment-requests') logAudit(u,'Requested payment',naira(body.amount)+' · '+body.invoice);
    else if(h=path.match(/^\/staff\/patients\/(.+)\/history$/)) logAudit(u,'Viewed patient record','',h[1]);
    else if(path.startsWith('/staff/patients?q=')) logAudit(u,'Searched patients','"'+decodeURIComponent(path.split('=')[1])+'"'); }
  return route2(method,path,body);
};
Object.assign(HealthPassAPI,{
  staffLogin:d=>request('POST','/portal/login',d), staffLogout:()=>request('POST','/portal/logout'), staffMe:()=>request('GET','/portal/me'),
  publicClinics:()=>request('GET','/portal/clinics'), portalRegisterClinic:d=>request('POST','/portal/clinic-register',d),
  registerStaff:d=>request('POST','/portal/staff-register',d), contactAdmin:d=>request('POST','/portal/contact',d),
  adminOverview:()=>request('GET','/admin/overview'), adminClinics:()=>request('GET','/admin/clinics'), adminAccounts:()=>request('GET','/admin/accounts'),
  adminPatients:()=>request('GET','/admin/patients'), adminAudit:()=>request('GET','/admin/audit'), adminMessages:()=>request('GET','/admin/messages'),
  setClinicStatus:(id,status)=>request('POST','/admin/clinics/'+id,{status}), setAccountStatus:(u,status)=>request('POST','/admin/accounts/'+u,{status})
});
