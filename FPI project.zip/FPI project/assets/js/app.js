/* app.js – patient mobile app. Hash router: #home #wallet #records #clinics #profile.
   Every view is an async function: fetch via HealthPassAPI -> return HTML string. render() puts it on screen.
   Security: if getMe() fails (no session / 401) the user is sent to login.html. Idle for 5 min => auto log out. */
let recTab = 'Visits', clinicQ = '', clinicState = '', me = null;
const hist = h => `<div class="item"><div><b>${h.title}</b><br><span class="muted small">${h.date} · ${h.clinic}<br>${h.detail}</span></div>
  <div style="text-align:right">${badge(h.type==='Visit'?'done':h.type==='Payment'?'neutral':'warn',h.type)}${h.amount?`<br><b class="out-neg">−${naira(-h.amount).replace('.00','')}</b>`:''}</div></div>`;
const empty = t => `<div class="card muted" style="text-align:center">${t}</div>`;
const views = {
  async home(){
    return `<div class="head"><div><p class="muted">Good morning,</p><h1>${me.name.split(' ')[0]} 👋</h1></div><button class="icon-btn" aria-label="Notifications" data-ic="bell" data-s="22"></button></div>
    <div class="hero-card"><div style="display:flex;flex-direction:column;justify-content:space-between"><b class="brand" style="color:#fff;font-size:18px" data-ic="cross">HealthPass</b>
      <div><h2 style="font-size:24px;margin-top:14px">${me.name}</h2><div style="opacity:.85">${me.id}</div><p class="small" style="margin-top:6px">Show this at your next clinic visit</p></div></div>
      <div style="text-align:right;display:flex;flex-direction:column;gap:8px;align-items:flex-end"><span class="small" style="opacity:.8">DIGITAL HEALTH ID</span><div class="qr">${qrSVG('HP:'+me.id)}</div></div></div>
    <div class="card" style="display:flex;justify-content:space-between;align-items:center"><div><span class="muted">Wallet balance</span><h1>${naira(me.balance)}</h1></div>
      <button class="btn sm" style="background:#E6F4F1;border:0" onclick="addMoney()" data-ic="plus">Add money</button></div>
    <h2 style="margin:22px 0 8px">Your care</h2>
    <div class="grid4"><a href="#records" onclick="recTab='Visits'"><span data-ic="calendar" data-s="28"></span>Visits</a><a href="#records" onclick="recTab='Vaccinations'"><span data-ic="syringe" data-s="28"></span>Vaccinations</a>
      <a href="#records" onclick="recTab='Antenatal'"><span data-ic="heart" data-s="28"></span>Pregnancy care</a><a href="#clinics"><span data-ic="pin" data-s="28"></span>Find a clinic</a></div>
    ${me.nextVisit?`<div class="banner" style="margin-top:12px;background:#FEF0C7"><span data-ic="calendar"></span><b>${me.nextVisit}</b></div>`:''}`;
  },
  async wallet(){
    const h = (await HealthPassAPI.getHistory()).filter(x=>x.amount);
    return `<div class="head"><h1>My wallet</h1><button class="icon-btn" aria-label="Help" data-ic="help"></button></div>
    <div class="hero-card" style="display:block"><span data-ic="wallet" style="opacity:.8"> Available balance</span><h1 style="font-size:40px;margin:8px 0;color:#fff">${naira(me.balance)}</h1><span class="small" style="opacity:.8">${me.name} · HealthPass wallet</span></div>
    <h2 style="margin-bottom:10px">Add money</h2><div class="chips">${[1000,2000,5000,10000].map(a=>`<button onclick="topUp(${a})">+${naira(a).replace('.00','')}</button>`).join('')}</div>
    <p class="small muted" style="margin:8px 0 18px">Demo top-up. The back end connects a payment gateway (Paystack/Flutterwave/bank transfer) here.</p>
    <h2>Recent transactions</h2>${h.map(hist).join('')||empty('No transactions yet.')}`;
  },
  async records(){
    const tabs = ['Visits','Vaccinations','Antenatal'];
    let body='';
    if(recTab==='Visits'){ const h=await HealthPassAPI.getHistory(); body=`<h2>Your care history</h2><p class="muted">Records from every clinic you have visited.</p>${h.map(hist).join('')||empty('No visits yet. Show your QR code at any HealthPass clinic.')}`; }
    else if(recTab==='Vaccinations'){ const v=await HealthPassAPI.getVaccinations(); body=`<h2>Your vaccinations</h2><p class="muted">Stay protected, one dose at a time.</p>
      <div style="display:flex;gap:8px;margin:8px 0">${badge('done','Done')}${badge('due','Due')}${badge('overdue','Overdue')}</div>
      ${v.map(x=>`<div class="item"><div><b>${x.name}</b><br><span class="muted small">${x.info}</span></div>${badge(x.status,x.status[0].toUpperCase()+x.status.slice(1))}</div>`).join('')||empty('No vaccinations recorded.')}
      <div class="banner" style="margin-top:14px;background:#E6F4F1;color:var(--teal)" data-ic="info">Missed a dose? Your clinic can help you catch up safely.</div>`; }
    else body = me.nextVisit ? `<h2>Antenatal care</h2><div class="card" style="margin-top:10px"><b>24 weeks</b><p class="muted">Routine antenatal check-up</p></div><div class="banner" style="margin-top:12px;background:#FEF0C7"><span data-ic="calendar"></span>${me.nextVisit}</div>` : empty('No antenatal records yet.');
    return `<div class="head"><div><h1>Health records</h1><span class="muted">${me.name} · ${me.id}</span></div><button class="icon-btn" aria-label="Help" data-ic="help"></button></div>
    <div class="tabs">${tabs.map(t=>`<button class="${t===recTab?'active':''}" onclick="recTab='${t}';render()">${t}</button>`).join('')}</div>${body}`;
  },
  async clinics(){
    return `<div class="head" style="justify-content:flex-start"><a href="#home" aria-label="Back" data-ic="back" data-s="26" style="color:var(--slate)"></a><h1>Find a clinic</h1></div>
    <input class="field" id="cq" placeholder="Search clinic name, town or state" value="${clinicQ}">
    <select class="field" id="cs" style="margin:10px 0"><option value="">All states</option>${STATES.map(s=>`<option ${s===clinicState?'selected':''}>${s}</option>`).join('')}</select>
    <div id="clist"></div>`;
  },
  async profile(){
    const nin = me.nin ? `<span id="nin">•••••••${me.nin.slice(-4)}</span> <a href="#profile" onclick="$('#nin').textContent='${me.nin}';return false">Show</a>` : '<span class="muted">Not added</span>';
    const row = (k,v) => `<div class="item"><span class="muted">${k}</span><b>${v}</b></div>`;
    return `<h1>Profile</h1><div class="ava-wrap"><div class="avatar">${me.photo?`<img src="${me.photo}" alt="Profile photo">`:initials(me.name)}</div>
      <label for="photo" aria-label="Change photo" data-ic="camera" data-s="18"></label><input id="photo" type="file" accept="image/*" class="hidden"></div>
    <h2 style="text-align:center">${me.name}</h2><p class="muted" style="text-align:center;margin-bottom:14px">${me.id}</p>
    <div class="card">${row('Phone number',me.phone.replace(/(\d{4})(\d{3})(\d{4})/,'$1 $2 $3'))}${row('Date of birth',me.dob)}${row('Gender',me.gender)}${row('NIN',nin)}</div>
    <button class="btn" style="margin-top:18px;color:var(--red)" onclick="confirmLogout()" data-ic="logout">Log out</button>`;
  }
};
function sheet(html){ $('#sheet-root').innerHTML=`<div class="sheet-back"><div class="sheet">${html}</div></div>`; hydrate($('#sheet-root')); }
const closeSheet = () => $('#sheet-root').innerHTML='';
function confirmLogout(){ sheet(`<h2>Log out of HealthPass?</h2><p class="muted">You will need your ID and PIN to log in again.</p><button class="btn primary" id="yes">Log out</button><button class="btn" onclick="closeSheet()">Stay logged in</button>`); $('#yes').onclick=logout; }
async function logout(){ try{ await HealthPassAPI.logout(); }catch(e){} location.replace('login.html'); }
function addMoney(){ location.hash='#wallet'; }
async function topUp(a){ await HealthPassAPI.topUp(a); render(); }
/* Resize a chosen photo to 256px JPEG so it is small enough to store/upload */
function savePhoto(file){ const img=new Image(); img.onload=async()=>{ const c=document.createElement('canvas'),s=256,r=Math.min(img.width,img.height);
  c.width=c.height=s; c.getContext('2d').drawImage(img,(img.width-r)/2,(img.height-r)/2,r,r,0,0,s,s);
  await HealthPassAPI.updateMe({photo:c.toDataURL('image/jpeg',.8)}); render(); }; img.src=URL.createObjectURL(file); }
async function loadClinics(){ const l=await HealthPassAPI.getClinics(clinicQ,clinicState);
  $('#clist').innerHTML = l.map(c=>`<div class="card" style="margin-bottom:10px"><b data-ic="hospital"> ${c.name}</b>${badge('ok','Verified clinic')}
    <p class="muted small" style="margin:6px 0">${c.address}, ${c.lga}, ${c.state} · <a href="tel:${c.phone.replace(/\s/g,'')}">${c.phone}</a></p>${(c.services||[]).map(s=>`<span class="tag">${s}</span>`).join('')}</div>`).join('') || empty('No clinic found. Try another name or state.');
  hydrate($('#clist')); }
async function render(){
  const name = (location.hash||'#home').slice(1);
  document.querySelectorAll('#nav a').forEach(a=>a.classList.toggle('active',a.hash==='#'+name||(name==='clinics'&&a.hash==='#home')));
  try{ me = await HealthPassAPI.getMe(); }catch(e){ return location.replace('login.html'); }
  try{ $('#view').innerHTML = await (views[name]||views.home)(); }catch(e){ $('#view').innerHTML='<div class="banner red">Could not load. Try again when online.</div>'; }
  hydrate();
  if(name==='clinics'){ $('#cq').oninput=e=>{clinicQ=e.target.value;loadClinics()}; $('#cs').onchange=e=>{clinicState=e.target.value;loadClinics()}; loadClinics(); }
  if(name==='profile') $('#photo').onchange=e=>e.target.files[0]&&savePhoto(e.target.files[0]);
}
/* Payment approval sheet: staff request a charge, patient approves with PIN (staff never see it). */
async function checkCharge(){
  let c; try{ c = await HealthPassAPI.getPendingCharge(); }catch(e){ return; }
  if(!c || $('.sheet-back') || me.balance < c.amount) return;
  sheet(`<b>${c.clinic}</b>${badge('ok','Verified clinic')}<h1>${c.clinic} wants to charge ${naira(c.amount).replace('.00','')}</h1>
    <div class="card"><div class="item"><span class="muted">For</span><b>${c.for}</b></div><div class="item"><span class="muted">Pay from</span><b>HealthPass wallet</b></div>
    <div class="item" style="border:0"><span class="muted">Balance after payment</span><b style="color:var(--teal)">${naira(me.balance-c.amount)}</b></div></div>
    <input class="field" id="pin" type="password" inputmode="numeric" maxlength="4" placeholder="Enter PIN (demo: 1234)"><p id="pinerr" class="banner red hidden"></p>
    <button class="btn primary" id="ok" data-ic="lock">Approve (PIN)</button><button class="btn" id="no">Decline</button>`);
  $('#ok').onclick = async () => { try{ await HealthPassAPI.answerCharge(c.id,{pin:$('#pin').value}); closeSheet(); render(); }
    catch(e){ $('#pinerr').textContent=e.message; $('#pinerr').classList.remove('hidden'); } };
  $('#no').onclick = async () => { await HealthPassAPI.answerCharge(c.id,{decline:true}); closeSheet(); };
}
/* Auto log-out after 5 minutes of no touches, so a stolen/borrowed phone is not an open book */
let idle; const resetIdle = () => { clearTimeout(idle); idle = setTimeout(logout, 5*60*1000); };
['click','touchstart','keydown'].forEach(e => addEventListener(e, resetIdle)); resetIdle();
watchConnection(); addEventListener('hashchange', render); render();
setTimeout(checkCharge, 4000); /* DEMO only. In production poll /me/pending-charge or use push/WebSocket. */
