/* admin.js – one console for two roles.
   admin    (main admin): Overview, Clinics (approve/reject/suspend), Sub admins & staff, Patients, Audit log, Messages
   subadmin (clinic admin): Overview, own Staff (approve/suspend), Patients seen at the clinic, own Audit log
   The API returns only what the role may see; the buttons here are convenience – the server must enforce permissions. */
let ME;
const menu = () => ME.role==='admin'
  ? [['overview','grid','Overview'],['clinics','hospital','Clinics'],['accounts','userplus','Sub admins & staff'],['patients','user','Patients'],['audit','records','Audit log'],['messages','bell','Messages']]
  : [['overview','grid','Overview'],['accounts','userplus','Staff'],['patients','user','Patients seen'],['audit','records','Audit log']];
const th = (...c) => '<tr>' + c.map(x=>`<th>${x}</th>`).join('') + '</tr>';
const stat = (t,v,s='') => `<div class="card"><span class="muted">${t}</span><b>${v}</b><span class="small muted">${s}</span></div>`;
/* Buttons offered for each status. data-kind + data-id + data-status are read by the click handler below. */
const actions = (kind,id,st) => `<div class="acts">` + ({
  pending:[['approved','Approve','primary'],['rejected','Reject','danger']], approved:[['suspended','Suspend','danger']],
  suspended:[['approved','Reactivate','']], rejected:[['approved','Approve','']] }[st]||[]).map(([s,l,c])=>`<button class="btn sm ${c}" data-kind="${kind}" data-id="${id}" data-status="${s}">${l}</button>`).join('') + `</div>`;
const views = {
  async overview(){ const o = await HealthPassAPI.adminOverview(), main = o.role==='admin';
    return `<div class="head"><div><h1>${main?'Platform overview':'Clinic overview'}</h1><span class="muted">${main?'Everything happening across all clinics.':'Your clinic, your staff, your audit trail.'}</span></div></div>
    <div class="stats">${main ? stat('Approved clinics',o.clinics)+stat('Clinics awaiting approval',o.pendingClinics,'Review in Clinics')+stat('Active staff',o.staff,o.subadmins+' clinic admins')+stat('Patients',o.patients)
      : stat('Active staff',o.staff)+stat('Staff awaiting approval',o.pendingStaff,'Review in Staff')+stat('Patients seen',o.patients)+stat('Actions (24h)',o.actions)}</div>
    ${main?stat('Audited actions (24h)',o.actions):''}`; },
  async clinics(){ const l = await HealthPassAPI.adminClinics();
    return `<h1 style="margin-bottom:16px">Clinics</h1><div class="card"><table>${th('Clinic','Location','Administrator','Licence','Status','')}${l.map(c=>`<tr><td><b>${c.name}</b><br><span class="small muted">${c.id}</span></td><td>${c.lga}, ${c.state}</td><td>${c.admin}</td><td>${c.licence||'—'}</td><td>${stBadge(c.status)}</td><td>${actions('clinic',c.id,c.status)}</td></tr>`).join('')}</table></div>`; },
  async accounts(){ const l = await HealthPassAPI.adminAccounts(), main = ME.role==='admin';
    return `<h1 style="margin-bottom:16px">${main?'Sub admins & staff':'Clinic staff'}</h1><p class="muted" style="margin-bottom:12px">Check each person's details before approving. One person, one login.</p>
    <div class="card"><table>${th('Name / username','Role','Clinic','Phone','Licence','Status','')}${l.map(a=>`<tr><td><b>${a.name}</b><br><span class="small muted">${a.username} · ${a.title||''}</span></td><td>${ROLE_LABEL[a.role]}</td><td>${a.clinic?a.clinic.name:'—'}</td><td>${a.phone||'—'}</td><td>${a.licence||'—'}</td><td>${stBadge(a.status)}</td><td>${actions('account',a.username,a.status)}</td></tr>`).join('')||'<tr><td colspan="7" class="muted">No accounts yet.</td></tr>'}</table></div>`; },
  async patients(){ const l = await HealthPassAPI.adminPatients();
    return `<h1 style="margin-bottom:16px">${ME.role==='admin'?'Patients':'Patients seen at your clinic'}</h1><div class="card"><table>${th('Patient','HealthPass ID','Phone','Sex','Last visit')}${l.map(p=>`<tr><td><b>${p.name}</b></td><td>${p.id}</td><td>${p.phone}</td><td>${p.sex}</td><td>${p.last}</td></tr>`).join('')||'<tr><td colspan="5" class="muted">No patients yet.</td></tr>'}</table></div>`; },
  async audit(){ const l = await HealthPassAPI.adminAudit();
    return `<div class="head"><h1>Audit log</h1><input class="field" id="af" placeholder="Filter by name, action, patient…" style="max-width:320px"></div>
    <p class="muted" style="margin-bottom:12px">Who did what, where and when. ${ME.role==='admin'?'All clinics.':'Your clinic only.'}</p>
    <div class="card"><table id="at">${th('Time','Person','Role','Clinic','Action','Details')}${l.map(x=>`<tr><td>${fmtTime(x.t)}</td><td><b>${x.name}</b><br><span class="small muted">${x.user}</span></td><td>${ROLE_LABEL[x.role]}</td><td>${x.clinic}</td><td>${x.action}</td><td>${[x.detail,x.patientId].filter(Boolean).join(' · ')||'—'}</td></tr>`).join('')}</table></div>`; },
  async messages(){ const l = await HealthPassAPI.adminMessages();
    return `<h1 style="margin-bottom:16px">Messages</h1>${l.map(m=>`<div class="card" style="margin-bottom:10px"><b>${m.name||'Unknown'}</b> <span class="small muted">${m.username||''} · ${m.clinicId||''} · ${fmtTime(m.t)}</span><p style="margin-top:6px">${m.text}</p></div>`).join('')||'<div class="card muted">No messages.</div>'}`; }
};
async function render(){
  const k = (location.hash||'#overview').slice(1), key = menu().some(m=>m[0]===k) ? k : 'overview';
  $('#nav').innerHTML = menu().map(([id,ic,l])=>`<a href="#${id}" data-ic="${id&&ic}" class="${id===key?'active':''}">${l}</a>`).join('');
  $('#view').innerHTML = '<p class="muted">Loading…</p>';
  try{ $('#view').innerHTML = await views[key](); }catch(e){ $('#view').innerHTML = '<div class="banner red">Could not load.</div>'; }
  hydrate();
  if(key==='audit') $('#af').oninput = e => document.querySelectorAll('#at tr:not(:first-child)').forEach(r => r.classList.toggle('hidden', !r.textContent.toLowerCase().includes(e.target.value.toLowerCase())));
}
document.addEventListener('click', async e => { const b = e.target.closest('[data-kind]'); if(!b) return;
  b.disabled = true; try{ b.dataset.kind==='clinic' ? await HealthPassAPI.setClinicStatus(b.dataset.id,b.dataset.status) : await HealthPassAPI.setAccountStatus(b.dataset.id,b.dataset.status); }catch(x){ alert('Not allowed.'); }
  render(); });
(async () => {
  ME = await requireRole(['admin','subadmin'], 'login.html');
  $('#roleLabel').textContent = ME.role==='admin' ? 'MAIN ADMIN' : 'CLINIC ADMIN'; $('#who').textContent = ME.name; $('#clinicOf').textContent = ME.clinic ? ME.clinic.name : 'All clinics';
  $('#logout').onclick = async () => { await HealthPassAPI.staffLogout(); location.replace('login.html'); };
  addEventListener('hashchange', render); render();
})();
