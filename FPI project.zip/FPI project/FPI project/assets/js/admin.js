/* admin.js – MAIN ADMIN console (HealthPass platform owner). Clinic admins have their own console in /clinic.
   Menus: Overview · Clinics · Clinic admins · Staff (search + filter by clinic) · Patients · Complaints · Audit log · Messages
   The main admin does NOT see clinic wallets: only each clinic's own admin can. The API enforces scope; buttons are convenience. */
let ME, CL = [], ACC = [];
const menu = [['overview','grid','Overview'],['clinics','hospital','Clinics'],['subadmins','userplus','Clinic admins'],['staff','user','Staff'],['patients','heart','Patients'],['complaints','alert','Complaints'],['audit','records','Audit log'],['messages','bell','Messages']];
const staffRows = (q,c) => ACC.filter(a=>a.role==='staff'&&(!c||a.clinicId===c)&&(a.name+a.username+(a.email||'')).toLowerCase().includes(q.toLowerCase()));
const staffTr = a => `<tr><td><b>${a.name}</b><br><span class="small muted">${a.username} · ${a.title||''}</span></td><td>${a.clinic?a.clinic.name:'—'}</td><td>${a.email||'—'}<br><span class="small muted">${a.phone||''}</span></td><td>${a.licence||'—'}</td><td>${stBadge(a.status)}</td><td>${actions('account',a.username,a.status)}</td></tr>`;
const views = {
  async overview(){ const [o,cp] = await Promise.all([HealthPassAPI.adminOverview(),HealthPassAPI.adminComplaints()]);
    return `<div class="head"><div><h1>Platform overview</h1><span class="muted">Everything happening across all clinics.</span></div></div>
    <div class="stats">${stat('Approved clinics',o.clinics)+stat('Awaiting approval',o.pendingClinics,'Review in Clinics')+stat('Active staff',o.staff,o.subadmins+' clinic admins')+stat('Patients',o.patients)}</div>
    <div class="stats" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">${stat('Open complaints',cp.filter(c=>c.status==='open').length)+stat('Audited actions (24h)',o.actions)}</div>`; },
  async clinics(){ const l = await HealthPassAPI.adminClinics();
    return `<h1 style="margin-bottom:16px">Clinics</h1><div class="card"><table>${th('Clinic','Location','Administrator','Licence','Status','')}${l.map(c=>`<tr><td><b>${c.name}</b><br><span class="small muted">${c.id}</span></td><td>${c.lga}, ${c.state}</td><td>${c.admin}</td><td>${c.licence||'—'}</td><td>${stBadge(c.status)}</td><td>${actions('clinic',c.id,c.status)}</td></tr>`).join('')}</table></div>`; },
  async subadmins(){ ACC = await HealthPassAPI.adminAccounts(); const l = ACC.filter(a=>a.role==='subadmin');
    return `<h1 style="margin-bottom:6px">Clinic admins</h1><p class="muted" style="margin-bottom:14px">One clinic admin per clinic. They approve their own staff and manage the clinic wallet.</p>
    <div class="card"><table>${th('Name / username','Clinic','Email / phone','Status','')}${l.map(a=>`<tr><td><b>${a.name}</b><br><span class="small muted">${a.username}</span></td><td>${a.clinic?a.clinic.name:'—'}</td><td>${a.email||'—'}<br><span class="small muted">${a.phone||''}</span></td><td>${stBadge(a.status)}</td><td>${actions('account',a.username,a.status)}</td></tr>`).join('')}</table></div>`; },
  async staff(){ [ACC,CL] = await Promise.all([HealthPassAPI.adminAccounts(),HealthPassAPI.adminClinics()]);
    return `<h1 style="margin-bottom:14px">Staff</h1><div class="row" style="margin-bottom:14px;flex-wrap:wrap"><input class="field" id="sq" placeholder="Search by name, username or email" style="flex:2;min-width:220px">
      <select class="field" id="sc" style="flex:1;min-width:200px"><option value="">All clinics</option>${CL.map(c=>`<option value="${c.id}">${c.name}</option>`).join('')}</select></div>
    <p class="small muted" id="scount" style="margin-bottom:8px"></p><div class="card"><table>${th('Name / username','Clinic','Email / phone','Licence','Status','')}<tbody id="stb"></tbody></table></div>`; },
  async patients(){ const l = await HealthPassAPI.adminPatients();
    return `<h1 style="margin-bottom:16px">Patients</h1><div class="card"><table>${th('Patient','HealthPass ID','Phone','Sex','Last visit')}${l.map(p=>`<tr><td><b>${p.name}</b></td><td>${p.id}</td><td>${p.phone}</td><td>${p.sex}</td><td>${p.last}</td></tr>`).join('')}</table></div>`; },
  async complaints(){ const l = await HealthPassAPI.adminComplaints();
    return `<h1 style="margin-bottom:16px">Complaints</h1>${l.map(c=>`<div class="card" style="margin-bottom:12px"><div class="head" style="margin-bottom:6px"><b>${c.clinic}</b>${badge(c.status==='open'?'warn':'ok',c.status==='open'?'Open':'Resolved')}</div>
      <p>${c.text}</p><p class="small muted" style="margin:6px 0 10px">From ${c.fromType} · ${c.fromName} · ${fmtTime(c.t)}</p>${c.status==='open'?`<button class="btn sm" data-kind="complaint" data-id="${c.id}">Mark resolved</button>`:''}</div>`).join('')||'<div class="card muted">No complaints.</div>'}`; },
  async audit(){ const l = await HealthPassAPI.adminAudit();
    return `<div class="head"><h1>Audit log</h1><input class="field" id="af" placeholder="Filter by name, action, patient…" style="max-width:320px"></div><p class="muted" style="margin-bottom:12px">Who did what, where and when. All clinics.</p>
    <div class="card"><table id="at">${th('Time','Person','Role','Clinic','Action','Details')}${l.map(x=>`<tr><td>${fmtTime(x.t)}</td><td><b>${x.name}</b><br><span class="small muted">${x.user}</span></td><td>${ROLE_LABEL[x.role]}</td><td>${x.clinic}</td><td>${x.action}</td><td>${[x.detail,x.patientId].filter(Boolean).join(' · ')||'—'}</td></tr>`).join('')}</table></div>`; },
  async messages(){ const l = await HealthPassAPI.adminMessages();
    return `<h1 style="margin-bottom:16px">Messages</h1>${l.map(m=>`<div class="card" style="margin-bottom:10px"><b>${m.name||'Unknown'}</b> <span class="small muted">${m.username||''} · ${m.clinicId||''} · ${fmtTime(m.t)}</span><p style="margin-top:6px">${m.text}</p></div>`).join('')||'<div class="card muted">No messages.</div>'}`; }
};
function fillStaff(){ const r = staffRows($('#sq').value,$('#sc').value); $('#stb').innerHTML = r.map(staffTr).join('') || '<tr><td colspan="6" class="muted">No staff match.</td></tr>'; $('#scount').textContent = r.length+' staff'; }
async function render(){
  const k = (location.hash||'#overview').slice(1), key = menu.some(m=>m[0]===k) ? k : 'overview';
  $('#nav').innerHTML = menu.map(([id,ic,l])=>`<a href="#${id}" data-ic="${ic}" class="${id===key?'active':''}">${l}</a>`).join('');
  $('#view').innerHTML = '<p class="muted">Loading…</p>';
  try{ $('#view').innerHTML = await views[key](); }catch(e){ $('#view').innerHTML = '<div class="banner red">Could not load.</div>'; }
  hydrate();
  if(key==='staff'){ $('#sq').oninput = fillStaff; $('#sc').onchange = fillStaff; fillStaff(); }
  if(key==='audit') $('#af').oninput = e => document.querySelectorAll('#at tr:not(:first-child)').forEach(r => r.classList.toggle('hidden', !r.textContent.toLowerCase().includes(e.target.value.toLowerCase())));
}
document.addEventListener('click', async e => { const b = e.target.closest('[data-kind]'); if(!b) return; b.disabled = true;
  try{ if(b.dataset.kind==='clinic') await HealthPassAPI.setClinicStatus(b.dataset.id,b.dataset.status);
       else if(b.dataset.kind==='account') await HealthPassAPI.setAccountStatus(b.dataset.id,b.dataset.status); else await HealthPassAPI.resolveComplaint(b.dataset.id); }
  catch(x){ alert(x.message==='403'?'Not allowed.':x.message); } render(); });
(async () => { ME = await requireRole(['admin'], 'login.html');
  $('#roleLabel').textContent = 'MAIN ADMIN'; $('#who').textContent = ME.name; $('#clinicOf').textContent = 'All clinics';
  $('#logout').onclick = async () => { await HealthPassAPI.staffLogout(); location.replace('login.html'); };
  addEventListener('hashchange', render); render(); })();
