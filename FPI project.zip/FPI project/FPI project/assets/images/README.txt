Put images (e.g. hero.jpg) here.
